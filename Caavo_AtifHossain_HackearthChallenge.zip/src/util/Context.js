import React from "react";
export default React.createContext({
  groups: [],
  addGroup: function addGroup(data) {},
});
